# L-Hub for Codex

Closed-source distribution. Source access is restricted.

L-Hub for Codex is a standalone MCP server that gives Codex access to multi-model routing, parallel answers, and consensus voting.

This repo is the Codex-specific line of L-Hub. It does not depend on Antigravity, Open VSX, or a dashboard UI.

Codex remains the main coding agent. L-Hub is the routing layer that lets Codex offload selected work to external model providers you configure yourself.

## What it provides

- `ai_ask`: Route one task to the best configured model.
- `ai_list_providers`: Inspect configured models and missing credentials.
- `ai_multi_ask`: Ask several models the same question in parallel.
- `ai_consensus`: Ask several models, then let a judge model pick the winner.

## Why this exists

- Keep Codex as your main agent while shifting selected work to other models.
- Use cheaper or more specialized providers for translation, summarization, code review, and long-context tasks.
- Compare multiple answers before you act on a risky change.

## Install

The intended product-style install flow is a hosted install script:

```bash
curl -fsSL https://raw.githubusercontent.com/readysteadyscience/l-hub-for-codex-downloads/main/install.sh | bash
```

That installer places the product under `~/.local/share/l-hub-for-codex/current` and creates these commands in `~/.local/bin`:

- `lhub`
- `lhub-console`
- `lhub-init`
- `lhub-doctor`
- `lhub-install-skill`

On interactive terminals, the installer now launches `lhub console` automatically after installation finishes.

On supported terminals such as WezTerm, iTerm2, and Kitty-compatible setups, L-Hub will also try to show the real bundled logo before the TUI loads. Other terminals automatically fall back to the built-in ASCII / Unicode brand screen.

If you want to skip that behavior:

```bash
LHUB_AUTO_LAUNCH=0 curl -fsSL https://raw.githubusercontent.com/readysteadyscience/l-hub-for-codex-downloads/main/install.sh | bash
```

If you want to disable the native image logo and keep only the text-mode branding:

```bash
LHUB_DISABLE_NATIVE_LOGO=1 lhub console
```

Codex stores MCP configuration in `~/.codex/config.toml`, and the Codex CLI, app, and IDE extension share that configuration.

You can also copy the sample files in this repo:

- `config.example.json`
- `codex.example.toml`
- `.env.example`

## Quick start

1. Create a starter config:

```bash
lhub init
```

If you are developing from this repo locally:

```bash
npm install
npm run build
node dist/bin/lhub-init.js
```

2. Edit the generated config file:

Default path:

```text
~/.config/l-hub-for-codex/config.json
```

Example:

```json
{
  "version": 1,
  "requestTimeoutMs": 60000,
  "defaultCriteria": "accuracy",
  "models": [
    {
      "id": "deepseek-v3",
      "modelId": "deepseek-chat",
      "apiKeyEnv": "DEEPSEEK_API_KEY",
      "enabled": true,
      "priority": 80
    },
    {
      "id": "openai-architect",
      "modelId": "gpt-5.4",
      "apiKeyEnv": "OPENAI_API_KEY",
      "enabled": true,
      "priority": 100
    }
  ]
}
```

3. Export your API keys:

```bash
export DEEPSEEK_API_KEY=...
export OPENAI_API_KEY=...
```

You can also manage keys through the Chinese terminal console:

```bash
lhub console
```

4. Run the setup check:

```bash
lhub doctor
```

Optional live connectivity probe:

```bash
lhub doctor --probe
```

Or open the Chinese terminal console:

```bash
lhub console
```

5. Verify in Codex:

```text
/mcp
```

## Project-scoped setup

If you want L-Hub only for one repo, you can use a project `.codex/config.toml` instead of a global one:

```toml
[mcp_servers.lhub]
command = "lhub"
args = ["mcp"]
env = { LHUB_CONFIG = "/absolute/path/to/config.json" }
```

For release steps and closed-source distribution notes, see `RELEASING.md`.

## Optional skill

L-Hub also works well with a small Codex skill that teaches Codex when to use `ai_ask`, `ai_multi_ask`, and `ai_consensus`.

Install the packaged skill to your personal Codex skills:

```bash
lhub install-skill
```

Or install it into the current repository for repo-local use:

```bash
lhub install-skill --project
```

The project variant installs to `.agents/skills/l-hub-for-codex`.

The bundled skill template also lives in `templates/skills/l-hub-for-codex` if you want to copy or version it in a different way.

If you want the repo-local skill to ship with the project, keep `.agents/skills/l-hub-for-codex` checked into git.

## Terminal console

`lhub-console` is a full-screen Chinese terminal workspace for first-time setup and routine maintenance.

It can:

- show configured models and key status
- show basic CLI status for Codex CLI, Gemini CLI, and Claude CLI
- support both keyboard navigation and mouse clicks inside the terminal
- enable or disable models
- add built-in preset models
- store API keys in `~/.config/l-hub-for-codex/keys.env`
- print the Codex MCP config snippet
- run live connectivity probes
- install the bundled L-Hub skill

Example:

```bash
lhub console
```

Usage notes:

- `Tab` / `Shift+Tab` switch sections
- `j` / `k` or arrow keys scroll the current page
- `1-6` jump directly to a section
- click the top tabs or bottom actions with the mouse, or use their hotkeys
- `q` exits the workspace

The local secret file is loaded automatically by `lhub-console`, `lhub-doctor`, and the MCP server.

## Closed-source distribution

The intended public user install path is a hosted install script plus a public tarball, not direct source access.

- Source repository: private
- Install channel: public downloads repo plus install script
- Runtime command surface: `lhub ...`
- GitHub source install is not part of the public setup flow

## Local development

Build the server:

```bash
npm install
npm run build
```

Run the MCP server directly:

```bash
node dist/bin/lhub-mcp.js
```

Create a config:

```bash
node dist/bin/lhub-init.js
```

Run diagnostics:

```bash
node dist/bin/lhub-doctor.js
```

Run diagnostics plus live provider probes:

```bash
node dist/bin/lhub-doctor.js --probe
```

Run the Chinese terminal console:

```bash
node dist/bin/lhub-console.js
```

Install the packaged skill locally:

```bash
node dist/bin/lhub-install-skill.js --project
```

## Release plan

This project is intended to ship as:

- A private source repository: `l-hub-for-codex`
- A public downloads repository: `l-hub-for-codex-downloads`
- An optional bundled skill: `l-hub-for-codex`

That keeps the Codex product line separate from the original Antigravity plugin.
