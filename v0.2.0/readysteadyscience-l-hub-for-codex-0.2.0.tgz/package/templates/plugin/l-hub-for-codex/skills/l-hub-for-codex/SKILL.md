---
name: l-hub-for-codex
description: Use L-Hub MCP tools for multi-model routing, answer comparison, and consensus workflows inside Codex
metadata:
  short-description: Route work through L-Hub
---

# L-Hub for Codex

Use this skill when the user wants Codex to consult external models through L-Hub instead of relying on the active Codex model alone.

This plugin bundles the `lhub` MCP server configuration. If the L-Hub runtime is installed and configured, Codex can call it directly.

## Use this skill when

- The user wants a cheaper or alternate model for a task.
- The user wants multiple model opinions before acting.
- The user wants a consensus or judge pass across several answers.
- The user asks to compare providers such as OpenAI, DeepSeek, Qwen, GLM, or Moonshot.

## Do not use this skill when

- The user only wants local file edits, shell commands, or repo changes with no need for outside model consultation.
- The user wants broad web research rather than model routing.
- L-Hub is not configured yet. In that case, use the setup flow first.

## Workflow

1. If setup is unclear, call `ai_list_providers` first.
2. Choose the narrowest useful tool:
   - `ai_ask` for one routed answer
   - `ai_multi_ask` for side-by-side comparison
   - `ai_consensus` for multi-answer judging
3. Keep prompts task-specific. Ask for only the answer shape the user needs.
4. After the tool returns, summarize the result and explain which model or route was used when that matters.

## Tool selection

### `ai_ask`

Use for the default case:
- one answer
- normal cost sensitivity
- user wants L-Hub to auto-route

### `ai_multi_ask`

Use when comparison matters:
- compare coding suggestions
- compare translation quality
- compare architecture opinions

### `ai_consensus`

Use when the decision is higher stakes:
- choosing between competing solutions
- sanity-checking a migration plan
- selecting the best explanation or review

## Notes

- Prefer `ai_ask` unless the user explicitly wants comparison or voting.
- If provider names are mentioned, pass them through as requested.
- If files are central to the task, include them through the tool's `file_paths` argument instead of pasting large file contents into the prompt.
