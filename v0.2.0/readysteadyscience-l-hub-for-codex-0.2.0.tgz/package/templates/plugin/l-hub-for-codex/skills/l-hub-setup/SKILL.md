---
name: l-hub-setup
description: Set up L-Hub for first use by entering provider keys, choosing a default model, and verifying connectivity
metadata:
  short-description: Set up L-Hub
---

# L-Hub Setup

Use this skill when the user wants to connect a provider, add an API key, choose a default model, or verify that L-Hub is ready inside Codex.

## Workflow

1. Prefer the terminal setup wizard over manual file edits.
2. Ask Codex to run `lhub setup` in the terminal when the user is ready to configure secrets.
3. Do not ask the user to paste API keys into the chat itself.
4. After setup completes, suggest `/mcp` or `lhub doctor --probe` if the user wants an extra verification pass.

## Notes

- The setup wizard writes the config and local env file for the user.
- The wizard also runs a live probe so the user gets an immediate success or failure result.
- If the runtime is missing, tell the user to install L-Hub first.
